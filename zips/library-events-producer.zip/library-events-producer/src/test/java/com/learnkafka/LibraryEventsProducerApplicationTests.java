package com.learnkafka;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class LibraryEventsProducerApplicationTests {

	@Test
	void contextLoads() {
	}

}
